//
//  random_generator.cpp
//  Project8
//
//  Created by Huanyu Liu on 3/2/19.
//  Copyright © 2019 Huanyu Liu. All rights reserved.
//

#include "random_generator.hpp"

random_generator::random_generator(unsigned long x){
    seed = x;
    m = (1 << 31) - (unsigned long)1;
    a = 168019;
}
random_generator::~random_generator(){
}

double random_generator::uniform_generator(){
    seed = (a * seed) % m;
    return (double)seed / m;
}

double *random_generator::normal_generator(int size){
    double *box_muller_norm = new double[size];
    for (int i = 0; i < size; i+=2){
        double u1 = uniform_generator();
        double u2 = uniform_generator();
        box_muller_norm[i] = sqrt(-2 * log(u1)) * cos(2 * M_PI * u2);
        box_muller_norm[i + 1] = sqrt(-2 * log(u1)) * sin(2 * M_PI * u2);
    }
    return box_muller_norm;
}

double *random_generator::brownian_motion(int size, double t){
    double *w = normal_generator(size);
    for (int i = 0; i < size; i++){
        w[i] *= sqrt(t);
    }
    return w;
}

//vector<double> random_generator::cir_stock_path(int size, double r0, double kappa, double r_bar, double delta, double sigma){
//    vector<double> path;
//    path.push_back(r0);
//    vector<double> bm = brownian_motion(size, delta);
//    for (int i = 0; i != size - 1; ++i){
//        path.push_back(path[i] + kappa * (r_bar - path[i]) * delta + sigma * sqrt(abs(path[i])) * bm[i]);
//    }
//    return path;
//}

double *random_generator::stock_path(int size, double t, double r, double sigma, double s0){
    double *path = new double[size];
    double delta = t/size;
    //double* bm = brownian_motion(size - 1, delta);
    double *bm = brownian_motion(size, delta);
    path[0] = s0;
    for (int i = 1; i < size; i++){
        if (path[i - 1] > 0){
            path[i] = path[i-1] + r * delta * path[i-1] + sigma * path[i - 1] * bm[i - 1];
        }
        else{
            path[i] = 0;
        }
    }
    delete [] bm;
    return path;
}
