//
//  accept_reject.hpp
//  Project2
//
//  Created by Huanyu Liu on 1/22/19.
//  Copyright © 2019 Huanyu Liu. All rights reserved.
//

#ifndef accept_reject_hpp
#define accept_reject_hpp

#include <stdio.h>
#include <cmath>

double t(double x);
double* accept_reject(int size);
#endif /* accept_reject_hpp */
