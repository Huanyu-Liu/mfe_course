//
//  max.hpp
//  Project4
//
//  Created by Huanyu Liu on 1/31/19.
//  Copyright © 2019 Huanyu Liu. All rights reserved.
//

#ifndef max_hpp
#define max_hpp

#include <stdio.h>

#endif /* max_hpp */

namespace max {
    inline double max(double a, double b){return a > b ? a : b;}
}
