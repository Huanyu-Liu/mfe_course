//
//  Proj6_2function.hpp
//  Project6
//
//  Created by Huanyu Liu on 2/21/19.
//  Copyright © 2019 Huanyu Liu. All rights reserved.
//

#ifndef Proj6_2function_hpp
#define Proj6_2function_hpp

#include <stdio.h>
#include <iostream>
#include "random_generator.hpp"
#endif /* Proj6_2function_hpp */

double * Proj6_2function(double lambda1 = 0.2, double lambda2 = 0.4, double T = 5);
