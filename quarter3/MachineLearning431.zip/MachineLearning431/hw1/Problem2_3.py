#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  3 20:28:08 2019

@author: huanyu
"""

import pandas as pd
data = pd.read_stata('/Users/huanyu/Desktop/MachineLearning431/hw1/StockRetAcct_insample.dta')
data.dro
